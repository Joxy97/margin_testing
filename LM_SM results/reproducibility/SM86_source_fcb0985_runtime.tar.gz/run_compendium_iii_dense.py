"""Frozen four-host Compendium III campaign on the existing n200 dense gka5e.

Prepare with ``prepare --input PATH --partition N --partitions-file PATH``.
Then use ``run``, ``run --dry-run``, ``run --resume`` or ``status --watch``.
Preparation and dry-run never dispatch solver trials. The 78 compatible models
run 100 seeds each; eight structured decoders are recorded as unsupported,
without fabricated trials. Each host runs only its frozen, disjoint partition.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import importlib.util
import os
from pathlib import Path
import shutil
import sys
import time
import json

ROOT = Path(__file__).resolve().parent
DEFAULT_CAMPAIGN = ROOT.parent / 'compendium_iii_dense_campaign_20261024'
sys.path.insert(0, str(ROOT / 'src'))
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ.setdefault(name, '1')

from qubo_benchmark.runtime.common import atomic, digest, filehash, read, source_snapshot_hash
from qubo_benchmark.runtime.compact_metrics import CHECKPOINTS
from qubo_solvers._compendium_iii_catalog import (
    COMPENDIUM_III_SOLVERS, COMPENDIUM_III_QUBO_SOLVERS,
    COMPENDIUM_III_STRUCTURED_SOLVERS,
)


def validate_partitions(plan, partition_id):
    """Reject omissions, duplicate assignments and structured solver dispatch."""
    if plan.get('schema_version') != 1:
        raise ValueError('Unsupported partition schema')
    if plan.get('collection') != list(COMPENDIUM_III_SOLVERS):
        raise ValueError('Partition collection must contain the ordered 86 Compendium III IDs')
    if plan.get('supported') != list(COMPENDIUM_III_QUBO_SOLVERS):
        raise ValueError('Partition supported inventory must contain the ordered 78 QUBO IDs')
    unsupported = plan.get('unsupported')
    if not isinstance(unsupported, list) or len(unsupported) != 8:
        raise ValueError('Record exactly eight unsupported structured models')
    unsupported_ids = []
    for record in unsupported:
        if (not isinstance(record, dict) or record.get('status') != 'unsupported'
                or not isinstance(record.get('reason'), str) or not record['reason'].strip()):
            raise ValueError('Unsupported records require a solver_id, status and reason')
        unsupported_ids.append(record.get('solver_id'))
    if (len(set(unsupported_ids)) != 8
            or set(unsupported_ids) != set(COMPENDIUM_III_STRUCTURED_SOLVERS)):
        raise ValueError('Unsupported inventory differs from the eight structured decoders')
    partitions = plan.get('partitions')
    if not isinstance(partitions, list) or len(partitions) != 4:
        raise ValueError('Expected four nonempty host partitions')
    ids, assignments = [], []
    for part in partitions:
        if (not isinstance(part, dict) or type(part.get('id')) is not int
                or not isinstance(part.get('host_label'), str) or not part['host_label'].strip()
                or not isinstance(part.get('solvers'), list) or not part['solvers']
                or any(not isinstance(solver, str) for solver in part['solvers'])):
            raise ValueError('Each partition requires an integer id, host_label and solver list')
        ids.append(part['id'])
        assignments.extend(part['solvers'])
    if set(ids) != {1, 2, 3, 4} or len(set(ids)) != len(ids):
        raise ValueError('Host partition IDs must be unique integers 1 through 4')
    if (len(assignments) != 78 or len(set(assignments)) != 78
            or set(assignments) != set(COMPENDIUM_III_QUBO_SOLVERS)):
        raise ValueError('Partitions must cover all 78 compatible solvers exactly once')
    if type(partition_id) is not int or partition_id not in ids:
        raise ValueError('Select a partition ID from 1 through 4')
    return next(part for part in partitions if part['id'] == partition_id)


def protocol(partition):
    return dict(problem='gka5e', variables=200, density='dense', reference=-35154,
                reference_type='OPTIMUM', partition_id=partition['id'],
                host_label=partition['host_label'], solvers=list(partition['solvers']),
                seeds=list(range(100)), budget_seconds=20.0, checkpoints=list(CHECKPOINTS),
                workers_per_gpu=1, wall_schedule=False, stop_on_optimum=True,
                total_collection=86, globally_supported_solvers=78,
                unsupported_solvers=list(COMPENDIUM_III_STRUCTURED_SOLVERS),
                unsupported_policy='Record unsupported metadata requirements; do not create trials.',
                tuning='Initial candidate defaults; no broad parameter tuning.',
                natural_return='Retain final incumbent through 20s; no restarts.',
                optimum_policy='Stop on independently rescored published optimum; carry to later checkpoints.')


def checked_identity(folder):
    identity = read(folder / 'identity.json')
    plan = read(folder / 'partitions.json')
    partition = validate_partitions(plan, identity['partition_id'])
    if identity['protocol'] != protocol(partition):
        raise ValueError('Prepared campaign protocol differs from this launcher or partition')
    if identity['partition_sha256'] != filehash(folder / 'partitions.json'):
        raise ValueError('Prepared partition file changed')
    if identity['selection_sha256'] != digest(partition):
        raise ValueError('Prepared partition selection changed')
    if identity['source_snapshot_sha256'] != source_snapshot_hash():
        raise ValueError('Solver/runtime source changed after campaign preparation')
    if identity['launcher_sha256'] != filehash(__file__):
        raise ValueError('Launcher changed after campaign preparation')
    for name, expected in identity['campaign_files'].items():
        if filehash(folder / name) != expected:
            raise ValueError('Prepared campaign file changed: ' + name)
    for name, expected in identity['input_files'].items():
        if filehash(ROOT / name) != expected:
            raise ValueError('Prepared input or provenance changed: ' + name)
    selected_settings = read(folder / 'solver_settings.json')
    if (list(sorted(selected_settings)) != sorted(partition['solvers'])
            or digest(selected_settings) != identity['parameters_sha256']):
        raise ValueError('Prepared complete solver settings changed')
    config = read(folder / 'config.json')['solvers']
    if any(config.get(solver) != parameters for solver, parameters in selected_settings.items()):
        raise ValueError('Prepared settings differ from the executable configuration')
    return identity


def prepare(folder, supplied, partition_id, partitions_file):
    from qubo_benchmark.continuous_catalog import verify_continuous_problem
    plan = read(partitions_file)
    partition = validate_partitions(plan, partition_id)
    if (folder / 'identity.json').exists():
        identity = checked_identity(folder)
        if (identity['partition_id'] != partition_id
                or identity['partition_sha256'] != filehash(partitions_file)):
            raise ValueError('This campaign already belongs to a different frozen partition')
        if filehash(supplied) != next(value for key, value in identity['input_files'].items()
                                      if key.endswith('.npz')):
            raise ValueError('Supplied input differs from the prepared dense input')
        print(json.dumps(dict(status='already_prepared', campaign=str(folder),
                              partition=partition_id, planned_trials=100 * len(partition['solvers']),
                              production_started=False), indent=2))
        return 0
    catalog = read(ROOT / 'configs/continuous_catalog.windows.json')
    entry = next(e for e in catalog['instances'] if e['instance_id'] == 'gka5e')
    if (entry['binary_variables'], entry['density_category'],
            entry['normalized_reference_objective_min']) != (200, 'dense', -35154):
        raise ValueError('Existing catalog no longer identifies the expected dense reference')
    expected = entry['normalized_sha256']
    if filehash(supplied) != expected:
        raise ValueError('Input differs from the existing n200 dense gka5e input')
    target = ROOT / entry['normalized_path']
    if target.exists() and filehash(target) != expected:
        raise ValueError('An input with a different checksum already occupies ' + str(target))
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        shutil.copyfile(supplied, target)
    provenance = read(ROOT / entry['verification_path'])
    provenance['normalized_sha256'] = expected
    entry['verification_path'] = 'benchmark_data/continuous12/compendium_iii_dense/gka5e.json'
    atomic(ROOT / entry['verification_path'], provenance)
    verification = verify_continuous_problem(entry, target, independent=True)
    if verification.get('status') != 'passed':
        raise ValueError('Independent dense input verification failed')
    for other in catalog['instances']:
        if other is not entry:
            other.update(preparation_status='unavailable',
                         unavailable_reason='This campaign selects only the existing n200 dense gka5e input.')
    # The existing CLI validates protected historical defaults even when none
    # are selected. Keep them exact, then add only this host's new candidates.
    config = read(ROOT / 'configs/benchmark_solvers.json')
    new = read(ROOT / 'configs/benchmark_solvers_compendium_iii.json')['solvers']
    if set(new) != set(COMPENDIUM_III_QUBO_SOLVERS) or len(new) != 78:
        raise ValueError('Expected exactly the 78 compatible Compendium III solver settings')
    selected_settings = {solver: new[solver] for solver in partition['solvers']}
    config['solvers'].update(selected_settings)
    config['description'] = 'Frozen Compendium III dense campaign; only this host partition is run.'
    atomic(folder / 'config.json', config)
    atomic(folder / 'solver_settings.json', selected_settings)
    atomic(folder / 'catalog.json', catalog)
    atomic(folder / 'input_proof.json', verification)
    folder.mkdir(parents=True, exist_ok=True)
    if partitions_file.resolve() != (folder / 'partitions.json').resolve():
        shutil.copyfile(partitions_file, folder / 'partitions.json')
    atomic(folder / 'unsupported.json', dict(schema_version=1, problem='gka5e',
           scope='Collection-wide exclusions; these eight records are not failed trials.',
           planned_trials=0, unsupported=plan['unsupported']))
    identity = dict(schema_version=1, partition_id=partition_id, protocol=protocol(partition),
                    partition_sha256=filehash(folder / 'partitions.json'),
                    selection_sha256=digest(partition), parameters_sha256=digest(selected_settings),
                    source_snapshot_sha256=source_snapshot_hash(), launcher_sha256=filehash(__file__),
                    campaign_files={name: filehash(folder / name) for name in
                                    ('config.json', 'solver_settings.json', 'catalog.json',
                                     'input_proof.json', 'partitions.json', 'unsupported.json')},
                    input_files={name: filehash(ROOT / name) for name in
                                 (entry['normalized_path'], entry['verification_path'])})
    atomic(folder / 'identity.json', identity)
    print(json.dumps(dict(status='prepared', campaign=str(folder), partition=partition_id,
                          host_label=partition['host_label'], solvers=len(partition['solvers']),
                          planned_trials=100 * len(partition['solvers']), global_planned_trials=7800,
                          unsupported_models=8, input=verification['instance_id'],
                          production_started=False), indent=2))
    return 0


def run(args):
    from qubo_benchmark.runtime import continuous_cli as cli
    folder = args.campaign
    evidence = checked_identity(folder)
    solvers = evidence['protocol']['solvers']
    selected_settings = read(folder / 'solver_settings.json')
    unsupported = read(folder / 'unsupported.json')
    output = (args.output or folder / 'results').resolve()
    original_prepare, original_job = cli.prepare, cli._job
    original_commit = cli.CompactStore.commit_seed
    started, fresh = time.monotonic(), 0

    def frozen_prepare(argv):
        prepared = original_prepare(argv)
        if prepared['solvers'] != solvers:
            raise ValueError('Unexpected solver selection for this frozen partition')
        if any(prepared['settings'][solver] != selected_settings[solver] for solver in solvers):
            raise ValueError('Resolved solver parameters differ from the frozen settings')
        if prepared['manifest']['inputs']['gka5e'] != next(
                value for key, value in evidence['input_files'].items() if key.endswith('.npz')):
            raise ValueError('Selected dense input changed')
        problem = prepared['manifest']['problems']
        if (len(problem) != 1 or problem[0]['id'] != 'gka5e' or problem[0]['n'] != 200
                or problem[0]['density'] != 'dense' or problem[0]['reference'] != -35154
                or problem[0]['reference_type'] != 'OPTIMUM'):
            raise ValueError('Selected dense problem/reference differs from the frozen protocol')
        execution = prepared['manifest']['execution']
        execution['wall_schedule_solvers'] = []
        execution['compendium_iii_schedule'] = 'finite fixed_steps; frozen initial candidate settings'
        execution['compendium_iii_campaign_identity'] = deepcopy(evidence)
        execution['compendium_iii_unsupported'] = deepcopy(unsupported)
        return prepared

    def frozen_job(prepared, argv, solver):
        return dict(original_job(prepared, argv, solver), wall_schedule=False)

    def commit(store, *values, **kwargs):
        nonlocal fresh
        committed = original_commit(store, *values, **kwargs)
        if not committed:
            return committed
        fresh += 1
        elapsed = time.monotonic() - started
        remaining = store.planned_count - store.completed_count
        status = dict(partition=evidence['partition_id'], completed=store.completed_count,
                      planned=store.planned_count, percent=100 * store.completed_count / store.planned_count,
                      elapsed_s=elapsed, eta_s=remaining * elapsed / fresh,
                      eta_policy='Measured rate since this process started; includes setup overhead.',
                      solver=values[0], seed=values[2], last_status=kwargs.get('status', 'complete'),
                      has_failures=store.has_failures,
                      note='Completion counts terminal attempts, including failures; excludes unsupported models.')
        atomic(output / 'campaign_progress.json', status)
        print(f"Partition {status['partition']}: {status['percent']:.2f}% "
              f"({status['completed']}/{status['planned']}), ETA {status['eta_s']/60:.1f} min, "
              f"failures={status['has_failures']}", flush=True)
        return committed

    argv = ['--continuous', '--variable-count', '200', '--density', 'dense',
            '--config', str(folder / 'config.json'), '--catalog', str(folder / 'catalog.json'),
            '--solvers', ','.join(solvers), '--runs', '100', '--seed-start', '0',
            '--devices', args.devices, '--require-gpu', '--seed-workers', '1', '--no-autotune',
            '--stop-on-optimum', '--keep-raw-results', '--no-plots', '--output-root', str(output)]
    if args.resume:
        argv += ['--resume', str(output)]
    if args.dry_run:
        argv += ['--dry-run', '--json']
    cli.prepare, cli._job, cli.CompactStore.commit_seed = frozen_prepare, frozen_job, commit
    try:
        return cli.main(argv)
    finally:
        cli.prepare, cli._job, cli.CompactStore.commit_seed = original_prepare, original_job, original_commit


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    stage = sub.add_parser('prepare', help='Freeze this host partition and verify input; no trials')
    stage.add_argument('--input', type=Path, required=True)
    stage.add_argument('--partition', type=int, choices=(1, 2, 3, 4), required=True)
    stage.add_argument('--partitions-file', type=Path, required=True)
    launch = sub.add_parser('run', help='Run this host partition, or validate with --dry-run')
    launch.add_argument('--devices', default='auto', help='Default: all visible CUDA GPUs')
    launch.add_argument('--resume', action='store_true', help='Resume exactly this frozen campaign')
    launch.add_argument('--dry-run', action='store_true', help='Validate GPU admission without solver trials')
    status = sub.add_parser('status', help='Read-only committed progress and ETA')
    status.add_argument('--watch', action='store_true')
    for child in (stage, launch, status):
        child.add_argument('--campaign', type=Path, default=DEFAULT_CAMPAIGN)
    for child in (launch, status):
        child.add_argument('--output', type=Path, help='Default: CAMPAIGN/results')
    args = parser.parse_args(argv)
    args.campaign = args.campaign.resolve()
    try:
        if args.command == 'prepare':
            return prepare(args.campaign, args.input, args.partition, args.partitions_file)
        if args.command == 'run':
            return run(args)
        identity = read(args.campaign / 'identity.json')
        print(f"Partition {identity['partition_id']}: "
              f"{100 * len(identity['protocol']['solvers'])} planned trials; "
              'eight collection-wide structured models are unsupported, not failed seeds.', flush=True)
        path = ROOT / 'tools/monitor_open_system_campaign.py'
        spec = importlib.util.spec_from_file_location('compendium_iii_campaign_monitor', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.main(['--output', str(args.output or args.campaign / 'results')]
                           + (['--watch'] if args.watch else []))
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(2, f'Compendium III campaign: {error}\n')


if __name__ == '__main__':
    raise SystemExit(main())
