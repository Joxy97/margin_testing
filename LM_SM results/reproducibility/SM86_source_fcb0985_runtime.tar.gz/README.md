# Solver library and continuous QUBO benchmarks

This branch contains the canonical 73-method solver library and the runtime
benchmark for the 25 GPU-capable methods compatible with all 37 prepared QUBOs.
This `solvers_testing` branch adds GPU-friendly SU(2) chiral isospin and gravity
tunneling solvers to the original 28 methods. It retains the compact 20-second
continuous runner, frozen solver presets, and provenance for one sparse and one
dense input at each of 100, 200, 500, 1000, 5000, and 10000 variables. Generated
benchmark results, environments, caches, bulk recovered continuous inputs, and
unrelated market datasets are not part of this deployment branch.

Inherited changes since `solvers_testing3` include the continuous protocol, tuned 20-second
configuration, known-optimum early stopping, quality-aware worker calibration,
compact crash-safe results, and post-run 1% hit exports. See
[README_BENCHMARKS.md](README_BENCHMARKS.md) and
[EARLY_STOP_AND_WORKERS.txt](EARLY_STOP_AND_WORKERS.txt) for the current protocol.
[BRANCH_CHANGES.md](BRANCH_CHANGES.md) documents this release and the inherited runtime.

## Added in solvers_testing

The 23 additional Hamiltonian candidates are available through the same library
factories, including compact sparse and resident execution. Their implementations,
IDs, initial settings, numerical choices and validation are documented in
[HAMILTONIAN_MODELS_IMPLEMENTATION.txt](HAMILTONIAN_MODELS_IMPLEMENTATION.txt).
Historical benchmark presets retain their original selection and parameters;
the new candidates require explicit configuration for a campaign.

- `lib_su2_chiral_isospin` / `SU2ChiralIsospin`: Bloch-vector annealing with
  implicit rank-two chirality and geometric midpoint rotations.
- `lib_gravity_tunneling` / `GravityTunneling`: softened interacting-swarm
  dynamics with reflected Verlet steps and archived stochastic binary jumps.

Both are registered with `create_solver()` and `create_bqm_solver()`, and included
in benchmark discovery. Torch-native batches, reusable buffers and CSR operators
keep search GPU-friendly; compact sparse inputs avoid dense host/device Q matrices.
Dynamics can use float32 while original-source candidate/result energies use
float64. Initial presets use 512 steps, 16 trajectories and checks every 16 steps;
see `configs/benchmark_solvers_new_physics.json`. Gravity's batch width defines
its interacting swarm and must stay fixed for a comparable experiment.
The original methods and their frozen presets are unchanged. These are exploratory
classical heuristics: defaults are not quality-tuned and optimality is not guaranteed.

```python
import torch
from qubo_solvers import QUBO, create_solver

problem = QUBO(torch.tensor([[-1., .25], [.25, -2.]],
                            dtype=torch.float64, device="cuda:0"))
solver = create_solver("lib_su2_chiral_isospin", dynamics_dtype="float32")
# Use "lib_gravity_tunneling" for the second method.
result = solver.solve(problem, restarts=16, batch_size=16, seed=42,
                      best_only=True, memory_limit_bytes=512 * 1024**2)
print(result.best_assignment, result.best_energy)
```

Implementation validation on Vast RTX 4070 SUPER GPUs passed 1,549 tests plus
50 subtests (three portfolio-only cases excluded), with sparse/dense CUDA smokes
through 10,000 variables. This is correctness/scaling evidence, not a full
100-seed quality campaign. Reproduce bounded timing/memory probes with
`tools/profile_new_physics_solvers.py`; generated logs, reports, recovered input
payloads, environments and credentials are not included in this release.

## Clone and install

```bash
git clone --depth 1 --single-branch --branch solvers_testing https://github.com/Joxy97/margin_testing.git
cd margin_testing
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[benchmark,dev]'
python -m pip check
```

On Windows, activate with `.venv\Scripts\Activate.ps1` instead. Use Python 3.10
or newer with compatible numerical-package wheels. For NVIDIA execution, install
a CUDA-enabled PyTorch wheel compatible with the host driver in this environment
before the editable install. If using a GPU image's preinstalled Torch, create
the environment with `python -m venv --system-site-packages .venv` instead.
Check the active interpreter, not a different system installation:

```bash
python -c "import torch; print(torch.__version__, torch.version.cuda, torch.cuda.is_available())"
python run_benchmark.py --list-solvers
python tools/stage_continuous_inputs.py --catalog configs/continuous_catalog.windows.json
python run_benchmark.py --variable-count 200 --sparse --seed-workers 1 \
  --catalog benchmark_data/continuous12/staged_catalog.json \
  --config configs/benchmark_solvers_selected_20s.json --require-gpu --dry-run
```

All raw source data, normalized matrices, reference witnesses and provenance are
included for the historical 37-input suite under `benchmark_data/qubo37`. The new
continuous inputs are deliberately excluded because of their size; the staging
command above downloads frozen public payloads, verifies their checksums and
canonical arrays, and writes a separate local `staged_catalog.json`. On the original
prepared Vast checkout, keep its existing verified inputs and default Linux catalog
instead of restaging them. Python packages still need installation; for completely
disconnected deployment, prepare matching wheels and transfer the prepared inputs.
An editable installation is required because data and configurations remain beside
the source rather than inside a standalone wheel.

## Run

```bash
# Continuous protocol: one input, all 25 solvers, seeds 0-99, one worker per GPU.
python run_benchmark.py --variable-count 200 --sparse --seed-workers 1 \
  --catalog benchmark_data/continuous12/staged_catalog.json \
  --config configs/benchmark_solvers_selected_20s.json --require-gpu \
  --output benchmark_results/200_sparse

# Run the dense test only after the sparse test finishes.
python run_benchmark.py --variable-count 200 --dense --seed-workers 1 \
  --catalog benchmark_data/continuous12/staged_catalog.json \
  --config configs/benchmark_solvers_selected_20s.json --require-gpu \
  --output benchmark_results/200_dense

python tools/postprocess_continuous_results.py benchmark_results/200_sparse --hit-percent 1
```

Valid continuous variable counts are `100`, `200`, `500`, `1000`, `5000`, and
`10000`. Each test is one uninterrupted optimization per solver/seed with checkpoints
at 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, and 20 seconds. `--seed-workers 1` means one
persistent worker on each selected GPU; use `--device cuda:0` when exactly one GPU
must be selected. Resume a continuous run with `python run_benchmark.py --resume
benchmark_results/200_sparse`.

## Historical fixed-budget runner

The positional interface below remains available for the inherited 37-input
protocol. Its results and timing definitions must not be mixed with continuous
results.

```bash
# Small optional GPU smoke: one representative, one seed, all 25 methods.
python run_benchmark.py 200 sparse 0.05 --instances representative --runs 1 --device cuda:0 --require-gpu --output-root results/gpu_smoke

# Normal command: all matching instances, 100 seeds each, all 25 methods,
# and every visible GPU. Concurrency is selected by a bounded pilot.
python run_benchmark.py 200 sparse 0.05

# Use all visible GPUs, one worker per GPU, without calibration.
python run_benchmark.py 200 sparse 1 --require-gpu --no-autotune

# Explicitly use two GPUs and two workers per GPU: four workers total.
python run_benchmark.py 200 sparse 1 --devices cuda:0,cuda:1 --seed-workers 2 --require-gpu
```

The normal command uses **all visible CUDA GPUs**, with CPU fallback if none
are available. `--require-gpu` forbids CPU fallback; `--device cuda:0` limits the
run to one GPU. A single invocation produces one complete result directory,
including every seed and every selected GPU. Do not also launch separate
benchmark processes on those GPUs.

Persistent workers keep their assigned GPU and reuse immutable inputs. A shared
queue schedules both different solvers and independent seeds concurrently.
The default `--seed-workers auto` tries bounded pilots with one, two and four
workers per GPU, subject to CPU and memory admission. It increases concurrency
only for a measured throughput gain greater than 10%, then freezes the counts.
Pilot trials are separate from benchmark statistics. `--seed-workers N` skips
calibration and requests N workers **per GPU**; `--no-autotune` keeps one per GPU.

Each trial retains its full solver wall-time budget. Startup, independent
scoring and result writing are outside it. Multiple workers on a GPU share
capacity during that budget, so their quality and timing distributions must be
distinguished from one-worker-per-GPU results. More workers and higher GPU
activity do not guarantee higher throughput or theoretical TFLOPS utilization.

Each configuration creates `results/<configuration_timestamp_id>/`, containing
separate `solvers/<id>/runs.csv`, `solutions.csv`, `trace.csv`, and `summary.csv`,
plus frozen JSON configuration, calibration evidence, hardware telemetry, logs
and durable resume records. CSV rows and the authoritative JSON journal are
saved after every trial; aggregate summaries refresh approximately every five
seconds and at completion.

```bash
python monitor_benchmark.py results/ACTUAL_TEST_DIRECTORY
python run_benchmark.py --resume results/ACTUAL_TEST_DIRECTORY
python aggregate_benchmarks.py results --output analysis
```

See [README_BENCHMARKS.md](README_BENCHMARKS.md) for all commands, protocol and
output fields, and [SOLVER_LIBRARY.md](SOLVER_LIBRARY.md) for the library API.
The historical portfolio application, unrelated tests/tools, market fixtures,
local virtual environments and generated results are not shipped here. Use the
shallow, single-branch clone above to avoid downloading historical Git objects.
Resume restores the original selected devices and worker counts without
recalibration. Runtime schema 4 includes the new execution policy and cannot
resume older source/protocol identities. See the benchmark README for admission,
timing, output fields and bounded tests. Four-RTX-3090 smoke results, measured
pilot throughput and short-budget limitations are in
[MULTIGPU_VALIDATION.md](MULTIGPU_VALIDATION.md). Validate measured throughput on
each target system; generated result artifacts are not bundled with the source.

The 20 open-system candidates are available as `OPEN_SYSTEM_SOLVERS`. See
[OPEN_SYSTEM_MODELS_IMPLEMENTATION.txt](OPEN_SYSTEM_MODELS_IMPLEMENTATION.txt)
for their IDs, numerical boundaries and small validation procedure. Select
`configs/benchmark_solvers_open_system.json` explicitly; historical presets
are unchanged.

For the prepared new20 n200 dense campaign (100 seeds, 20-second cap), use
`python -u run_open_system_dense.py run`. Preparation, monitoring and resume
commands are in [OPEN_SYSTEM_DENSE_CAMPAIGN.txt](OPEN_SYSTEM_DENSE_CAMPAIGN.txt).
